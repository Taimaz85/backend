# models.py
from extensions import db

class Message(db.Model):
    __tablename__ = 'tbl_messages'
    ID = db.Column(db.Integer, primary_key=True)
    UserID = db.Column(db.Integer)
    Content = db.Column(db.Text)
    TimeStamp = db.Column(db.DateTime, default=db.func.current_timestamp())

    def __init__(self, UserID, Content):
        self.UserID = UserID
        self.Content = Content
