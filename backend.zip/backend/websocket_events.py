from flask_socketio import emit
from extensions import db
from models import Message # Ensure Message is imported from where it is defined

def init_socketio(socketio):    
    @socketio.on('message')
    def handle_message(msg):
        user_id = msg.get('UserID')
        content = msg.get('Content')
        
        # Save the message to the database
        new_message = Message(UserID = user_id, Content = content)
        db.session.add(new_message)
        db.session.commit()
        
        # Broadcast the message to all connected clients
        emit('message', msg, broadcast=True)