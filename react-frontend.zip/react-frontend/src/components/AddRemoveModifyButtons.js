import React from 'react';

function AddRemoveModifyButtons({ onAdd, onRemove, onModify }) {
    return (
        <div style={{ marginBottom: '20px' }}>
            <button onClick={onAdd} style={{ marginRight: '10px' }}>Add</button>
            <button onClick={onRemove} style={{ marginRight: '10px' }}>Remove</button>
            <button onClick={onModify}>Modify</button>
        </div>
    );
}

export default AddRemoveModifyButtons;
