import logo from './logo.svg';
import './App.css';
import './components/additionalamount'
import RetrieveAdditionalAmount from './components/additionalamount';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        My thesis application
      </header>
      <RetrieveAdditionalAmount/>
    </div>
  );
}

export default App;
