from flask import Blueprint, jsonify, render_template, request
import mysql.connector
from mysql.connector import Error


# Create a Blueprint for recipe related routes
recipe_bp = Blueprint('recipe', __name__)

# MySQL database configuration
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Tamiloos3855",
    database="bitnjoy"
)

# Route to serve the HTML page
@recipe_bp.route('/')
def index():
    return render_template('main.html')


# API route to fetch data from MySQL and return it as JSON
@recipe_bp.route('/recipe')
def recipe():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM tbl_recipe")
    result = cursor.fetchall()
    
    data = [dict(zip([column[0] for column in cursor.description], row)) for row in result]
    return render_template('recipe.html', data=data)

# API route to handle adding new recipe
@recipe_bp.route('/api/add_recipe', methods=['POST'])
def add_recipe():
    try:
        # Extract data from the incoming request (JSON payload)
        data = request.get_json()
        
        # Get values from the JSON request
        userID = data.get('field1')
        foodName = data.get('field2')
        productID = data.get('field3')
        productWeightTypeID = data.get('field4')
        productQuantity = data.get('field5')
        foodStuffID = data.get('field6')
        foodStuffWeightTypeID = data.get('field7')
        foodStaffQuantity = data.get('field8')
        preprationMethod = data.get('field9')
        preprationTime = data.get('field10')
        dishSide = data.get('field11')
        vitaminID = data.get('field12')
        mineralID = data.get('field13')
        calorie = data.get('field14')
        commentID = data.get('field15')
        description = data.get('field16')
        status = data.get('field17')
        
        # Insert the new entry into the database
        cursor = db.cursor()
        query = "INSERT INTO tbl_recipe (userID, foodName, productID, productWeightTypeID, productQuantity,\
            foodStuffID, foodStuffWeightTypeID, foodStuffQuantity, preprationMethod, preprationTime, dishSide,\
                vitaminID, mineralID, calorie, commentID, description, status) VALUES \
                    (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        cursor.execute(query, (userID, foodName, productID, productWeightTypeID, productQuantity, foodStuffID,\
            foodStuffWeightTypeID, foodStaffQuantity, preprationMethod, preprationTime, dishSide, vitaminID,\
                mineralID, calorie, commentID, description, status))
        db.commit()
        
        return jsonify({"message": "Recipe added successfully!"})
    
    except Error as e:
        return jsonify({"error": str(e)}),400

# API route to handle deleting a recipe by ID
@recipe_bp.route('/api/delete_recipe/<int:id>', methods=['DELETE'])
def delete_recipe(id):
    try:
        # Create a cursor
        cursor = db.cursor()

        # Execute the DELETE query
        query = "DELETE FROM tbl_recipe WHERE id = %s"
        cursor.execute(query, (id,))
        db.commit()

        # Check if the row was actually deleted
        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "Recipe deleted successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to fetch recipe by ID
@recipe_bp.route('/api/get_recipe/<int:id>', methods=['GET'])
def get_recipe(id):
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_recipe WHERE id = %s", (id,))
        result = cursor.fetchone()

        if result:
            return jsonify(result), 200
        else:
            return jsonify({"error": "Record not found"}), 404

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to handle modifying a recipe
@recipe_bp.route('/api/modify_recipe/<int:id>', methods=['PUT'])
def modify_recipe(id):
    try:
        # Extract data from the request
        data = request.get_json()

        userID = data.get('field1')
        foodName = data.get('field2')
        productID = data.get('field3')
        productWeightTypeID = data.get('field4')
        productQuantity = data.get('field5')
        foodStuffID = data.get('field6')
        foodStuffWeightTypeID = data.get('field7')
        foodStuffQuantity = data.get('field8')
        preprationMethod = data.get('field9')
        preprationTime = data.get('field10')
        dishSide = data.get('field11')
        vitaminID = data.get('field12')
        mineralID = data.get('field13')
        calorie = data.get('field14')
        commentID = data.get('field15')
        description = data.get('field16')
        status = data.get('field17')

        # Update the database record
        cursor = db.cursor()
        query = "UPDATE tbl_recipe SET UserID = %s, FoodName = %s, ProductID = %s,\
            ProductWeightTypeID = %s, ProductQuantity = %s, FoodStuffID = %s,\
                FoodStuffWeightTypeID = %s, FoodStuffQuantity = %s, PreprationMethod = %s,\
                    PreprationTime = %s, DishSide = %s, VitaminID = %s, MineralID = %s,\
                        Calorie = %s, CommentID = %s, Description = %s, Status = %s WHERE id = %s"
        cursor.execute(query, (userID, foodName, productID, productWeightTypeID, productQuantity,\
            foodStuffID, foodStuffWeightTypeID, foodStuffQuantity, preprationMethod, preprationTime,\
                dishSide, vitaminID, mineralID, calorie, commentID, description, status, id))
        db.commit()

        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "Recipe updated successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500
    
