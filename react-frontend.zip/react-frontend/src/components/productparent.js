import { useState } from 'react';

function RetrieveProductParent() {
    const [productParents, setProductParents] = useState();

    return (
        <div>
            
        </div>
    )
}