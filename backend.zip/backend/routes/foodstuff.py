from flask import Blueprint, jsonify, render_template, request
import mysql.connector
from mysql.connector import Error

# Create a Blueprint for foodstuff related routes
foodstuff_bp = Blueprint('foodstuff', __name__)

# MySQL database configuration
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Tamiloos3855",
    database="bitnjoy"
)

# Route to serve the HTML page
@foodstuff_bp.route('/')
def index():
    return render_template('main.html')

# API route to fetch data from MySQL and return it as JSON
@foodstuff_bp.route('/foodstuff')
def foodstuff():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM tbl_foodstuff")
    result = cursor.fetchall()
    
    data = [dict(zip([column[0] for column in cursor.description], row)) for row in result]
    return render_template('foodstuff.html', data=data)


@foodstuff_bp.route('/foodstuffgetroutexample')
def foodstuff2():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM tbl_foodstuff")
    result = cursor.fetchall()
    
    data = [dict(zip([column[0] for column in cursor.description], row)) for row in result]
    return jsonify(data)

# API route to handle adding new foodstuff
@foodstuff_bp.route('/api/add_foodstuff', methods=['POST'])
def add_foodstuff():
    try:
        # Extract data from the incoming request (JSON payload)
        data = request.get_json()
        
        # Get values from the JSON request
        userID = data.get('field1')
        name = data.get('field2')
        pictureURL = data.get('field3')
        mineralID = data.get('field4')
        mineralQuantity = data.get('field5')
        mineralWeightTypeID = data.get('field6')
        vitaminID = data.get('field7')
        vitaminQuantity = data.get('field8')
        vitaminWeightTypeID = data.get('field9')
        calorie = data.get('field10')
        description = data.get('field11')
        status = data.get('field12')
        
        # Insert the new entry into the database
        cursor = db.cursor()
        query = "INSERT INTO tbl_foodstuff (userID, name, pictureURL, mineralID, mineralQuantity, mineralWeightTypeID, \
            vitaminID, vitaminQuantity, vitaminWeightTypeID, calorie, description, status) VALUES \
                (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        cursor.execute(query, (userID, name, pictureURL, mineralID, mineralQuantity, mineralWeightTypeID, \
            vitaminID, vitaminQuantity, vitaminWeightTypeID, calorie, description, status))
        db.commit()
        
        return jsonify({"message": "Foodstuff added successfully!"})
    
    except Error as e:
        return jsonify({"error": str(e)}),400
    
# API route to handle deleting a foodstuff by ID
@foodstuff_bp.route('/api/delete_foodstuff/<int:id>', methods=['DELETE'])
def delete_foodstuff(id):
    try:
        # Create a cursor
        cursor = db.cursor()

        # Execute the DELETE query
        query = "DELETE FROM tbl_foodstuff WHERE id = %s"
        cursor.execute(query, (id,))
        db.commit()

        # Check if the row was actually deleted
        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "Foodstuff deleted successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to fetch foodstuff by ID
@foodstuff_bp.route('/api/get_foodstuff/<int:id>', methods=['GET'])
def get_foodstuff(id):
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_foodstuff WHERE id = %s", (id,))
        result = cursor.fetchone()

        if result:
            return jsonify(result), 200
        else:
            return jsonify({"error": "Record not found"}), 404

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to handle modifying a foodstuff
@foodstuff_bp.route('/api/modify_foodstuff/<int:id>', methods=['PUT'])
def modify_foodstuff(id):
    try:
        # Extract data from the request
        data = request.get_json()

        userID = data.get('field1')
        name = data.get('field2')
        pictureURL = data.get('field3')
        mineralID = data.get('field4')
        mineralQuantity = data.get('field5')
        mineralWeightTypeID = data.get('field6')
        vitaminID = data.get('field7')
        vitaminQuantity = data.get('field8')
        vitaminWeightTypeID = data.get('field9')
        calorie = data.get('field10')
        description = data.get('field11')
        status = data.get('field12')
        
        # Update the database record
        cursor = db.cursor()
        query = "UPDATE tbl_foodstuff SET UserID = %s, Name = %s, PictureURL = %s, MineralID = %s,\
            MineralQuantity = %s, MineralWeightTypeID = %s, VitaminID = %s, VitaminQuantity = %s,\
                VitaminWeightTypeID = %s, Calorie = %s, Description = %s, Status = %s WHERE id = %s"
        cursor.execute(query, (userID, name, pictureURL, mineralID, mineralQuantity, mineralWeightTypeID,\
            vitaminID, vitaminQuantity, vitaminWeightTypeID, calorie, description, status, id))
        db.commit()

        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "Foodstuff updated successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500
    