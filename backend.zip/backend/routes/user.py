from flask import Blueprint, jsonify, render_template, request
import mysql.connector
from mysql.connector import Error

# Create a Blueprint for user related routes
user_bp = Blueprint('user', __name__)

# MySQL database configuration
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Tamiloos3855",
    database="bitnjoy"
)

# Route to serve the HTML page
@user_bp.route('/')
def index():
    return render_template('main.html')

# API route to fetch data from MySQL and return it as JSON
@user_bp.route('/user')
def user():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM tbl_user")
    result = cursor.fetchall()
    
    data = [dict(zip([column[0] for column in cursor.description], row)) for row in result]
    return render_template('user.html', data=data)

# API route to handle adding new user
@user_bp.route('/api/add_user', methods=['POST'])
def add_user():
    try:
        # Extract data from the incoming request (JSON payload)
        data = request.get_json()
        
        # Get values from the JSON request
        userRegisterID = data.get('field1')
        firstName = data.get('field2')
        lastName = data.get('field3')
        birthDate = data.get('field4')
        email = data.get('field5')
        password = data.get('field6')
        address = data.get('field7')
        pictureURL = data.get('field8')
        verify = data.get('field9')
        userStatusID = data.get('field10')
        userTypeID = data.get('field11')
        description = data.get('field12')
        status = data.get('field13')
        
        # Insert the new entry into the database
        cursor = db.cursor()
        query = "INSERT INTO tbl_user (UserRegisterID, FirstName, LastName, BirthDate,\
                    Email, Password, Address, PictureURL, Verify, UserStatusID, UserTypeID,\
                        Description, Status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        cursor.execute(query, (userRegisterID, firstName, lastName, birthDate, email,
                                password, address, pictureURL, verify, userStatusID, userTypeID,
                                    description, status))
        db.commit()
        
        return jsonify({"message": "New user added successfully!"}), 201
    
    except Error as e:
        return jsonify({"error": str(e)}),400

# API route to handle deleting a user by ID
@user_bp.route('/api/delete_user/<int:id>', methods=['DELETE'])
def delete_user(id):
    try:
        # Create a cursor
        cursor = db.cursor()

        # Execute the DELETE query
        query = "DELETE FROM tbl_user WHERE id = %s"
        cursor.execute(query, (id,))
        db.commit()

        # Check if the row was actually deleted
        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "User deleted successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to fetch user by ID
@user_bp.route('/api/get_user/<int:id>', methods=['GET'])
def get_user(id):
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_user WHERE id = %s", (id,))
        result = cursor.fetchone()

        if result:
            return jsonify(result), 200
        else:
            return jsonify({"error": "Record not found"}), 404

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to handle modifying a user
@user_bp.route('/api/modify_user/<int:id>', methods=['PUT'])
def modify_user(id):
    try:
        # Extract data from the request
        data = request.get_json()

        userRegisterID = data.get('field1')
        firstName = data.get('field2')
        lastName = data.get('field3')
        birthDate = data.get('field4')
        # email = data.get('field5')
        # password = data.get('field6')
        address = data.get('field7')
        pictureURL = data.get('field8')
        verify = data.get('field9')
        userStatusID = data.get('field10')
        userTypeID = data.get('field11')
        description = data.get('field12')
        status = data.get('field13')

        # Update the database record
        cursor = db.cursor()
        query = "UPDATE tbl_user SET UserRegisterID = %s, FirstName = %s, LastName = %s, \
            BirthDate = %s, Address = %s, PictureURL = %s, Verify = %s, UserStatusID = %s, \
                UserTypeID = %s, Description = %s, Status = %s WHERE id = %s"
        cursor.execute(query, (userRegisterID, firstName, lastName, birthDate, address, \
            pictureURL, verify, userStatusID, userTypeID, description, status, id))
        db.commit()

        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "User updated successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500
    
