// Handle the Confirm button
confirmAdd.addEventListener('click', function() {
    const field1 = document.getElementById('field1').value;
    const field2 = document.getElementById('field2').value;
    const field3 = document.getElementById('field3').value;

    // Create an object to send to the server
    const newData = {
        field1: field1,
        field2: field2,
        field3: field3
    };

    // Send the data to the server using fetch (you can use Axios if you prefer)
    fetch('/api/add_productparent', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(newData)
    })
    .then(response => response.json())
    .then(data => {
        console.log('Success:', data);
        // Hide the form
        addForm.style.display = 'none';
        // Optionally, reload the page or update the table with the new data
    })
    .catch((error) => {
        console.error('Error:', error);
    });
});
