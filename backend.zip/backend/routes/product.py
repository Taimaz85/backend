from flask import Blueprint, jsonify, render_template, request
import mysql.connector
from mysql.connector import Error

# Create a Blueprint for product related routes
product_bp = Blueprint('product', __name__)

# MySQL database configuration
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Tamiloos3855",
    database="bitnjoy"
)

# Route to serve the HTML page
@product_bp.route('/')
def index():
    return render_template('main.html')

# API route to fetch data from MySQL and return it as JSON
@product_bp.route('/product')
def product():
    
    # Connect to MySQL
    cursor = db.cursor()
    cursor.execute("SELECT * FROM tbl_productinfo")
    result = cursor.fetchall()
    
    data = [dict(zip([column[0] for column in cursor.description], row)) for row in result]
    return render_template('product.html', data=data)

# API route to handle adding new product
@product_bp.route('/api/add_product', methods=['POST'])
def add_product():
    try:
        # Extract data from the incoming request (JSON payload)
        data = request.get_json()
        
        # Get values from the JSON request
        productParentID = data.get('field1')
        name = data.get('field2')
        brandNameID = data.get('field3')
        manufacturingCompanyID = data.get('field4')
        meatPercentage = data.get('field5')
        weight = data.get('field6')
        weightTypeID = data.get('field7')
        price = data.get('field8')
        currencyTypeID = data.get('field9')
        healthRate = data.get('field10')
        produceDate = data.get('field11')
        expireDate = data.get('field12')
        stock = data.get('field13')
        imageURL = data.get('field14')
        commentID = data.get('field15')
        rate = data.get('field16')
        description = data.get('field17')
        status = data.get('field18')
        
        # Insert the new entry into the database
        cursor = db.cursor()
        query = "INSERT INTO tbl_productinfo (productParentID, name, brandNameID, manufacturingCompanyID,\
            meatPercentage, weight, weightTypeID, price, currencyTypeID, healthRate, produceDate, expireDate,\
                stock, imageURL, commentID, rate, description, status) VALUES\
                    (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s ,%s, %s, %s, %s)"
        cursor.execute(query, (productParentID, name, brandNameID, manufacturingCompanyID, meatPercentage,\
            weight, weightTypeID, price, currencyTypeID, healthRate, produceDate, expireDate, stock,\
                imageURL, commentID, rate, description, status))
        db.commit()
        
        return jsonify({"message": "Product added successfully!"})
    
    except Error as e:
        return jsonify({"error": str(e)}),400
    
# API route to hanle deleting a product by ID
@product_bp.route('/api/delete_product/<int:id>', methods=['DELETE'])
def delete_product(id):
    try:
        # Create a cursor
        cursor = db.cursor()
        
        # Execute the DELETE query
        query = "DELETE FROM tbl_productinfo WHERE id = %s"
        cursor.execute(query, (id,))
        db.commit()
        
        # Check in the row was actually deleted
        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404
        
        return jsonify({"message": " Product deleted successfully!"}), 200
    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to fetch product by ID
@product_bp.route('/api/get_product/<int:id>', methods=['GET'])
def get_product(id):
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_productinfo WHERE id = %s", (id,))
        result = cursor.fetchone()

        if result:
            return jsonify(result), 200
        else:
            return jsonify({"error": "Record not found"}), 404

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to handle modifying a product
@product_bp.route('/api/modify_product/<int:id>', methods=['PUT'])
def modify_product(id):
    try:
        # Extract data from the request
        data = request.get_json()

        productParentID = data.get('field1')
        name = data.get('field2')
        brandNameID = data.get('field3')
        manufacturingCompanyID = data.get('field4')
        meatPercentage = data.get('field5')
        weight = data.get('field6')
        weightTypeID = data.get('field7')
        price = data.get('field8')
        currencyTypeID = data.get('field9')
        healthRate = data.get('field10')
        produceDate = data.get('field11')
        expireDate = data.get('field12')
        stock = data.get('field13')
        imageURL = data.get('field14')
        commentID = data.get('field15')
        rate = data.get('field16')
        description = data.get('field17')
        status = data.get('field18')

        # Update the database record
        cursor = db.cursor()
        query = "UPDATE tbl_productinfo SET ProductParentID = %s, Name = %s, BrandNameID = %s,\
            ManufacturingCompanyID = %s, MeatPercentage = %s, Weight = %s, WeightTypeID = %s,\
                Price = %s, CurrencyTypeID = %s, HealthRate = %s, ProduceDate = %s,\
                    ExpireDate = %s, Stock = %s, ImageURL = %s, CommentID = %s, Rate = %s,\
                        Description = %s, Status = %s WHERE id = %s"
        cursor.execute(query, (productParentID, name, brandNameID, manufacturingCompanyID,\
            meatPercentage, weight, weightTypeID, price, currencyTypeID, healthRate,\
                produceDate, expireDate, stock, imageURL, commentID, rate, description, status, id))
        db.commit()

        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "Product updated successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500
    
