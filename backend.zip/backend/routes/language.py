from flask import Blueprint, jsonify, render_template, request
import mysql.connector
from mysql.connector import Error


# Create a Blueprint for language related routes
language_bp = Blueprint('language', __name__)

# MySQL database configuration
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Tamiloos3855",
    database="bitnjoy"
)

# Route to serve the HTML page
@language_bp.route('/')
def index():
    return render_template('main.html')

# API route to fetch data from MySQL and return it as JSON
@language_bp.route('/language')
def language():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM tbl_language")
    result = cursor.fetchall()
    
    data = [dict(zip([column[0] for column in cursor.description], row)) for row in result]
    return render_template('language.html', data=data)

# API route to handle adding new language
@language_bp.route('/api/add_language', methods=['POST'])
def add_language():
    try:
        # Extract data from the incoming request (JSON payload)
        data = request.get_json()
        
        # Get values from the JSON request
        name = data.get('field1')
        flagURL = data.get('field2')
        unicode = data.get('field3')
        description = data.get('field4')
        status = data.get('field5')
        
        # Insert the new entry into the database
        cursor = db.cursor()
        query = "INSERT INTO tbl_language (Name, FlagURL, Unicode, Description, Status) VALUES (%s, %s, %s, %s, %s)"
        cursor.execute(query, (name, flagURL, unicode, description, status))
        db.commit()
        
        return jsonify({"message": "New language added successfully!"})
    
    except Error as e:
        return jsonify({"error": str(e)}),400

# API route to handle deleting a language by ID
@language_bp.route('/api/delete_language/<int:id>', methods=['DELETE'])
def delete_language(id):
    try:
        # Create a cursor
        cursor = db.cursor()

        # Execute the DELETE query
        query = "DELETE FROM tbl_language WHERE id = %s"
        cursor.execute(query, (id,))
        db.commit()

        # Check if the row was actually deleted
        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "Language deleted successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to fetch language by ID
@language_bp.route('/api/get_language/<int:id>', methods=['GET'])
def get_language(id):
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_language WHERE id = %s", (id,))
        result = cursor.fetchone()

        if result:
            return jsonify(result), 200
        else:
            return jsonify({"error": "Record not found"}), 404

    except Error as e:
        return jsonify({"error": str(e)}), 500

# API route to handle modifying a language
@language_bp.route('/api/modify_language/<int:id>', methods=['PUT'])
def modify_language(id):
    try:
        # Extract data from the request
        data = request.get_json()

        name = data.get('field1')
        flagURL = data.get('field2')
        unicode = data.get('field3')
        description = data.get('field4')
        status = data.get('field5')

        # Update the database record
        cursor = db.cursor()
        query = "UPDATE tbl_language SET Name = %s, FlagURL = %s, Unicode = %s,\
            Description = %s, Status = %s WHERE id = %s"
        cursor.execute(query, (name, flagURL, unicode, description, status, id))
        db.commit()

        if cursor.rowcount == 0:
            return jsonify({"message": "No record found with the provided ID"}), 404

        return jsonify({"message": "Language updated successfully!"}), 200

    except Error as e:
        return jsonify({"error": str(e)}), 500