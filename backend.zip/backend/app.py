from flask import Flask, render_template, jsonify
from extensions import db, socketio
from websocket_events import init_socketio
import os

# only use cors in development
import flask_cors

# Blueprints
from routes.user import user_bp
from routes.order import order_bp
from routes.recipe import recipe_bp
from routes.brand import brand_bp
from routes.language import language_bp
from routes.productParent import productparent_bp
from routes.vitamin import vitamin_bp
from routes.mineral import mineral_bp
from routes.product import product_bp
from routes.userStatus import userstatus_bp
from routes.weightType import weighttype_bp
from routes.userType import usertype_bp
from routes.paymentType import paymenttype_bp
from routes.currencytype import currencytype_bp
from routes.verificationtype import verificationtype_bp
from routes.userregister import userregister_bp
from routes.amountCalculationtype import amountcalculationtype_bp
from routes.additionalAmount import additionalamount_bp
from routes.discountAmount import discountamount_bp
from routes.foodstuff import foodstuff_bp
from routes.currencyParityRate import currencyparityrate_bp

# Database configuration
app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Tamiloos3855@localhost/bitnjoy'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# initialize extensions with the app
db.init_app(app)
socketio.init_app(app)

# fix local development cors issue
cors = flask_cors.CORS()
cors.init_app(app)

# initialize websocket events
init_socketio(socketio)

# Route to serve the HTML page
@app.route('/')
def index():
    return render_template('main.html')

app.register_blueprint(user_bp)
app.register_blueprint(order_bp)
app.register_blueprint(recipe_bp)
app.register_blueprint(brand_bp)
app.register_blueprint(language_bp)
app.register_blueprint(productparent_bp)
app.register_blueprint(vitamin_bp)
app.register_blueprint(mineral_bp)
app.register_blueprint(product_bp)
app.register_blueprint(userstatus_bp)
app.register_blueprint(weighttype_bp)
app.register_blueprint(usertype_bp)
app.register_blueprint(paymenttype_bp)
app.register_blueprint(currencytype_bp)
app.register_blueprint(verificationtype_bp)
app.register_blueprint(amountcalculationtype_bp)
app.register_blueprint(additionalamount_bp)
app.register_blueprint(discountamount_bp)
app.register_blueprint(foodstuff_bp)
app.register_blueprint(currencyparityrate_bp)
app.register_blueprint(userregister_bp)
    
if __name__ == '__main__':
    with app.app_context():
        db.create_all() # Create tables if they don't exist
    socketio.run(app, debug=True)